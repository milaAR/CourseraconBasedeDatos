package hantaro.com.petagram.db;

public final class ConstantsDataBase {

    public static final String TABLE_LIKES_PET_ID_PET = "pet_likes_id_pet";
    public static final String TABLE_PETS = "pets_table";
    public static String DATABASE_NAME = "pet_db";
    public static int DATABASE_VERSION = 1;
    public static String TABLE_PET_ID = "id";
    public static String TABLE_PET_NUMBER_OF_LIKES = "likes_count";
    public static String TABLE_PET_NAME = "name";
    public static String TABLE_PET_IMAGE = "image";
    public static String TABLE_PET_LIKES = "likes";
    public static String TABLE_LIKES_PET_ID = "pet_likes_id";
}
