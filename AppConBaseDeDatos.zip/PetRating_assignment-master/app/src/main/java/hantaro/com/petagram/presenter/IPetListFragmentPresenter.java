package hantaro.com.petagram.presenter;

public interface IPetListFragmentPresenter {

    void getDataFromDB();

    void showData();


}
